<?php



namespace Prokerala\Api\Numerology\Result\Chaldean;

use Prokerala\Api\Numerology\Result\Pythagorean\Number;

class IdentityInitialCodeNumber extends Number
{
}
