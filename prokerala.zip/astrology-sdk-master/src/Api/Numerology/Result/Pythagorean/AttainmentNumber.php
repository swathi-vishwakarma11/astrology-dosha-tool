<?php



namespace Prokerala\Api\Numerology\Result\Pythagorean;

class AttainmentNumber extends Number
{
}
