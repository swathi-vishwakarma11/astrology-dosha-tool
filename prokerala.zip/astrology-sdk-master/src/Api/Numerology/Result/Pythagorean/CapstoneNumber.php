<?php



namespace Prokerala\Api\Numerology\Result\Pythagorean;

class CapstoneNumber extends Number
{
}
