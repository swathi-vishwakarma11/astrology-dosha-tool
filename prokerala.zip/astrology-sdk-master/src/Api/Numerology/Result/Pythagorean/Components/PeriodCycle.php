<?php
declare(strict_types=1);

namespace Prokerala\Api\Numerology\Result\Pythagorean\Components;

class PeriodCycle extends NumerologyNumber
{

}
