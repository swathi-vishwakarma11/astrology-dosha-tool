<?php

namespace Prokerala\Api\Numerology\Result\Pythagorean\Components;

class PlanesOfExpression extends NumerologyNumber
{
}
