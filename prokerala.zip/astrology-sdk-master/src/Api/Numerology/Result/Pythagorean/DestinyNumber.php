<?php



namespace Prokerala\Api\Numerology\Result\Pythagorean;

class DestinyNumber extends Number
{
}
