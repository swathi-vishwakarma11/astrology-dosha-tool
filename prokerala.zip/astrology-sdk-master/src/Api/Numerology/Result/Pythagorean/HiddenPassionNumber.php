<?php



namespace Prokerala\Api\Numerology\Result\Pythagorean;

class HiddenPassionNumber extends Number
{
}
