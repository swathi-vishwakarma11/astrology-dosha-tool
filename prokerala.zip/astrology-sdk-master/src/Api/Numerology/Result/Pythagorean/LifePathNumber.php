<?php



namespace Prokerala\Api\Numerology\Result\Pythagorean;

class LifePathNumber extends Number
{
}
