<?php



namespace Prokerala\Api\Numerology\Result\Pythagorean;

class MaturityNumber extends Number
{
}
