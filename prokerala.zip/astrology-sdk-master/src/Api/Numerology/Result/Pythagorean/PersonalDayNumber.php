<?php



namespace Prokerala\Api\Numerology\Result\Pythagorean;

class PersonalDayNumber extends Number
{
}
