<?php



namespace Prokerala\Api\Numerology\Result\Pythagorean;

class PersonalYearNumber extends Number
{
}
