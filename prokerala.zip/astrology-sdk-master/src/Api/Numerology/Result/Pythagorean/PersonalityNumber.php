<?php



namespace Prokerala\Api\Numerology\Result\Pythagorean;

class PersonalityNumber extends Number
{
}
