<?php



namespace Prokerala\Api\Numerology\Result\Pythagorean;

class RationalThoughtNumber extends Number
{
}
