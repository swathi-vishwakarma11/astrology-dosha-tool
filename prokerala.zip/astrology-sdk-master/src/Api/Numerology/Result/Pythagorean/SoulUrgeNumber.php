<?php



namespace Prokerala\Api\Numerology\Result\Pythagorean;

class SoulUrgeNumber extends Number
{
}
