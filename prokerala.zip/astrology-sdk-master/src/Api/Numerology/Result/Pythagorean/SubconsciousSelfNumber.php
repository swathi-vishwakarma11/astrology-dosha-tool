<?php



namespace Prokerala\Api\Numerology\Result\Pythagorean;

class SubconsciousSelfNumber extends Number
{
}
